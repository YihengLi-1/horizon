import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { EnrollmentStatus, Prisma } from "@prisma/client";
import { Request } from "express";
import { addCartItemSchema, dropEnrollmentSchema, submitCartSchema } from "@sis/shared";
import { z } from "zod";
import { AuditService } from "../audit/audit.service";
import { isPassingGrade } from "../common/grade.utils";
import { PrismaService } from "../common/prisma.service";

type AddCartInput = z.infer<typeof addCartItemSchema>;
type SubmitCartInput = z.infer<typeof submitCartSchema>;
type DropEnrollmentInput = z.infer<typeof dropEnrollmentSchema>;

type Meeting = {
  weekday: number;
  startMinutes: number;
  endMinutes: number;
};

type CartItemWithSection = Prisma.CartItemGetPayload<{
  include: {
    section: {
      include: {
        term: true;
        meetingTimes: true;
        course: {
          include: {
            prerequisiteLinks: true;
          };
        };
      };
    };
  };
}>;

type ExistingEnrollmentWithMeetings = Prisma.EnrollmentGetPayload<{
  include: {
    section: {
      include: {
        meetingTimes: true;
      };
    };
  };
}>;

type CompletedEnrollmentWithCourse = Prisma.EnrollmentGetPayload<{
  include: {
    section: {
      include: {
        course: true;
      };
    };
  };
}>;

function hasMeetingConflict(a: Meeting[], b: Meeting[]): boolean {
  return a.some((m1) =>
    b.some((m2) => m1.weekday === m2.weekday && m1.startMinutes < m2.endMinutes && m2.startMinutes < m1.endMinutes)
  );
}

@Injectable()
export class RegistrationService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly auditService: AuditService
  ) {}

  private isSerializationFailure(error: unknown): boolean {
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2034") {
      return true;
    }

    const message = error instanceof Error ? error.message.toLowerCase() : "";
    return message.includes("serialization") || message.includes("deadlock");
  }

  private isIsolationLevelUnsupported(error: unknown): boolean {
    const message = error instanceof Error ? error.message.toLowerCase() : "";
    return message.includes("isolation") && message.includes("not supported");
  }

  private async runEnrollmentTransactionWithRetry<T>(
    fn: (tx: Prisma.TransactionClient) => Promise<T>
  ): Promise<T> {
    let useSerializable = true;
    let lastError: unknown;

    for (let attempt = 1; attempt <= 3; attempt += 1) {
      try {
        if (useSerializable) {
          return await this.prisma.$transaction(fn, {
            isolationLevel: Prisma.TransactionIsolationLevel.Serializable
          });
        }

        return await this.prisma.$transaction(fn);
      } catch (error) {
        lastError = error;

        if (useSerializable && this.isIsolationLevelUnsupported(error)) {
          useSerializable = false;
          attempt -= 1;
          continue;
        }

        if (this.isSerializationFailure(error) && attempt < 3) {
          continue;
        }

        throw error;
      }
    }

    throw lastError;
  }

  private async getSectionEnrollmentStats(
    client: PrismaService | Prisma.TransactionClient,
    sectionIds: string[]
  ): Promise<{
    enrolledCountBySection: Map<string, number>;
    maxWaitlistPositionBySection: Map<string, number>;
  }> {
    if (sectionIds.length === 0) {
      return {
        enrolledCountBySection: new Map<string, number>(),
        maxWaitlistPositionBySection: new Map<string, number>()
      };
    }

    const [activeCounts, waitlistMaxRows] = await Promise.all([
      client.enrollment.groupBy({
        by: ["sectionId"],
        where: {
          sectionId: { in: sectionIds },
          status: { in: ["ENROLLED"] }
        },
        _count: { _all: true }
      }),
      client.enrollment.groupBy({
        by: ["sectionId"],
        where: {
          sectionId: { in: sectionIds },
          status: "WAITLISTED"
        },
        _max: { waitlistPosition: true }
      })
    ]);

    const enrolledCountBySection = new Map<string, number>();
    for (const row of activeCounts) {
      enrolledCountBySection.set(row.sectionId, row._count._all);
    }

    const maxWaitlistPositionBySection = new Map<string, number>();
    for (const row of waitlistMaxRows) {
      maxWaitlistPositionBySection.set(row.sectionId, row._max.waitlistPosition ?? 0);
    }

    return { enrolledCountBySection, maxWaitlistPositionBySection };
  }

  private getPassedCourseIds(completedEnrollments: CompletedEnrollmentWithCourse[]): Set<string> {
    return new Set(
      completedEnrollments
        .filter((enrollment) => isPassingGrade(enrollment.finalGrade))
        .map((enrollment) => enrollment.section.courseId)
    );
  }

  private buildEnrollmentPlan(params: {
    studentId: string;
    termId: string;
    term: {
      startDate: Date;
      maxCredits: number;
    };
    now: Date;
    cartItems: CartItemWithSection[];
    existingEnrollments: ExistingEnrollmentWithMeetings[];
    passedCourseIds: Set<string>;
    enrolledCountBySection: Map<string, number>;
    maxWaitlistPositionBySection: Map<string, number>;
  }): Prisma.EnrollmentCreateManyInput[] {
    const {
      studentId,
      termId,
      term,
      now,
      cartItems,
      existingEnrollments,
      passedCourseIds,
      enrolledCountBySection,
      maxWaitlistPositionBySection
    } = params;

    const scheduledMeetings: Meeting[] = existingEnrollments
      .filter((enrollment) => enrollment.status === "ENROLLED" || enrollment.status === "PENDING_APPROVAL")
      .flatMap((enrollment) =>
        enrollment.section.meetingTimes.map((meeting) => ({
          weekday: meeting.weekday,
          startMinutes: meeting.startMinutes,
          endMinutes: meeting.endMinutes
        }))
      );

    const existingSectionIds = new Set(existingEnrollments.map((item) => item.sectionId));

    let totalCredits = existingEnrollments
      .filter((e) => e.status === "ENROLLED" || e.status === "PENDING_APPROVAL")
      .reduce((sum, e) => sum + e.section.credits, 0);

    const waitlistNextPositionBySection = new Map<string, number>(maxWaitlistPositionBySection);
    const toCreate: Prisma.EnrollmentCreateManyInput[] = [];

    for (const item of cartItems) {
      const section = item.section;

      if (existingSectionIds.has(section.id)) {
        throw new BadRequestException({
          code: "ALREADY_REGISTERED",
          message: `Already enrolled/waitlisted for section ${section.sectionCode}`
        });
      }

      const startProxy = section.startDate ?? term.startDate;
      if (now >= startProxy) {
        throw new BadRequestException({
          code: "SECTION_ALREADY_STARTED",
          message: `Cannot self-add after section start for ${section.sectionCode}`
        });
      }

      const missingPrerequisites = section.course.prerequisiteLinks
        .map((link) => link.prerequisiteCourseId)
        .filter((courseId) => !passedCourseIds.has(courseId));

      if (missingPrerequisites.length > 0) {
        throw new BadRequestException({
          code: "PREREQUISITE_NOT_MET",
          message: `Prerequisites not met for section ${section.sectionCode}`
        });
      }

      const activeCount = enrolledCountBySection.get(section.id) ?? 0;

      let status: EnrollmentStatus;
      let waitlistPosition: number | undefined;

      if (activeCount >= section.capacity) {
        status = "WAITLISTED";
        const basePosition = waitlistNextPositionBySection.get(section.id) ?? 0;
        waitlistPosition = basePosition + 1;
        waitlistNextPositionBySection.set(section.id, waitlistPosition);
      } else if (section.requireApproval) {
        status = "PENDING_APPROVAL";
      } else {
        status = "ENROLLED";
        enrolledCountBySection.set(section.id, activeCount + 1);
      }

      if (status === "ENROLLED" || status === "PENDING_APPROVAL") {
        const thisMeetings: Meeting[] = section.meetingTimes.map((meeting) => ({
          weekday: meeting.weekday,
          startMinutes: meeting.startMinutes,
          endMinutes: meeting.endMinutes
        }));

        if (hasMeetingConflict(thisMeetings, scheduledMeetings)) {
          throw new BadRequestException({
            code: "TIME_CONFLICT",
            message: `Section ${section.sectionCode} conflicts with your schedule`
          });
        }

        if (totalCredits + section.credits > term.maxCredits) {
          throw new BadRequestException({
            code: "CREDIT_LIMIT_EXCEEDED",
            message: `Credit limit (${term.maxCredits}) exceeded`
          });
        }

        totalCredits += section.credits;
        scheduledMeetings.push(...thisMeetings);
      }

      toCreate.push({
        studentId,
        termId,
        sectionId: section.id,
        status,
        waitlistPosition
      });

      existingSectionIds.add(section.id);
    }

    return toCreate;
  }

  async getCart(studentId: string, termId: string) {
    return this.prisma.cartItem.findMany({
      where: { studentId, termId },
      include: {
        section: {
          include: {
            course: true,
            term: true,
            meetingTimes: true,
            enrollments: {
              where: { status: { in: ["ENROLLED", "PENDING_APPROVAL"] } }
            }
          }
        }
      },
      orderBy: { createdAt: "asc" }
    });
  }

  async addToCart(studentId: string, input: AddCartInput) {
    const section = await this.prisma.section.findUnique({
      where: { id: input.sectionId },
      include: { term: true }
    });

    if (!section || section.termId !== input.termId) {
      throw new NotFoundException({ code: "SECTION_NOT_FOUND", message: "Section not found for term" });
    }

    const existingActive = await this.prisma.enrollment.findFirst({
      where: {
        studentId,
        sectionId: section.id,
        status: { in: ["ENROLLED", "WAITLISTED", "PENDING_APPROVAL"] }
      }
    });

    if (existingActive) {
      throw new BadRequestException({ code: "ALREADY_REGISTERED", message: "Already enrolled/waitlisted for this section" });
    }

    try {
      return await this.prisma.cartItem.create({
        data: {
          studentId,
          termId: input.termId,
          sectionId: input.sectionId
        }
      });
    } catch {
      throw new BadRequestException({ code: "ALREADY_IN_CART", message: "Section already in cart" });
    }
  }

  async removeCartItem(studentId: string, cartItemId: string) {
    const item = await this.prisma.cartItem.findUnique({ where: { id: cartItemId } });
    if (!item || item.studentId !== studentId) {
      throw new NotFoundException({ code: "CART_ITEM_NOT_FOUND", message: "Cart item not found" });
    }

    await this.prisma.cartItem.delete({ where: { id: cartItemId } });
    return { id: cartItemId };
  }

  async submitCart(studentId: string, input: SubmitCartInput, req: Request) {
    const term = await this.prisma.term.findUnique({ where: { id: input.termId } });
    if (!term) {
      throw new NotFoundException({ code: "TERM_NOT_FOUND", message: "Term not found" });
    }

    const now = new Date();
    if (now < term.registrationOpenAt || now > term.registrationCloseAt) {
      throw new BadRequestException({
        code: "REGISTRATION_WINDOW_CLOSED",
        message: "Registration window is closed"
      });
    }

    const cartItems: CartItemWithSection[] = await this.prisma.cartItem.findMany({
      where: { studentId, termId: input.termId },
      include: {
        section: {
          include: {
            term: true,
            meetingTimes: true,
            course: {
              include: {
                prerequisiteLinks: true
              }
            }
          }
        }
      },
      orderBy: { createdAt: "asc" }
    });

    if (cartItems.length === 0) {
      throw new BadRequestException({ code: "EMPTY_CART", message: "Cart is empty" });
    }

    const sectionIds = Array.from(new Set(cartItems.map((item) => item.sectionId)));

    const [existingEnrollments, completedEnrollments, sectionStats] = await Promise.all([
      this.prisma.enrollment.findMany({
        where: {
          studentId,
          termId: input.termId,
          status: { in: ["ENROLLED", "PENDING_APPROVAL", "WAITLISTED"] }
        },
        include: {
          section: { include: { meetingTimes: true } }
        }
      }),
      this.prisma.enrollment.findMany({
        where: {
          studentId,
          status: "COMPLETED"
        },
        include: {
          section: {
            include: { course: true }
          }
        }
      }),
      this.getSectionEnrollmentStats(this.prisma, sectionIds)
    ]);

    const passedCourseIds = this.getPassedCourseIds(completedEnrollments);

    // Pre-validate with grouped counts and waitlist maxima (avoids per-section queries).
    this.buildEnrollmentPlan({
      studentId,
      termId: input.termId,
      term: {
        startDate: term.startDate,
        maxCredits: term.maxCredits
      },
      now,
      cartItems,
      existingEnrollments,
      passedCourseIds,
      enrolledCountBySection: new Map(sectionStats.enrolledCountBySection),
      maxWaitlistPositionBySection: new Map(sectionStats.maxWaitlistPositionBySection)
    });

    const created = await this.runEnrollmentTransactionWithRetry(async (tx) => {
      const txCartItems: CartItemWithSection[] = await tx.cartItem.findMany({
        where: { studentId, termId: input.termId },
        include: {
          section: {
            include: {
              term: true,
              meetingTimes: true,
              course: {
                include: {
                  prerequisiteLinks: true
                }
              }
            }
          }
        },
        orderBy: { createdAt: "asc" }
      });

      if (txCartItems.length === 0) {
        throw new BadRequestException({ code: "EMPTY_CART", message: "Cart is empty" });
      }

      const txSectionIds = Array.from(new Set(txCartItems.map((item) => item.sectionId)));

      const [txExistingEnrollments, txCompletedEnrollments, txSectionStats] = await Promise.all([
        tx.enrollment.findMany({
          where: {
            studentId,
            termId: input.termId,
            status: { in: ["ENROLLED", "PENDING_APPROVAL", "WAITLISTED"] }
          },
          include: {
            section: { include: { meetingTimes: true } }
          }
        }),
        tx.enrollment.findMany({
          where: {
            studentId,
            status: "COMPLETED"
          },
          include: {
            section: {
              include: { course: true }
            }
          }
        }),
        this.getSectionEnrollmentStats(tx, txSectionIds)
      ]);

      const txPassedCourseIds = this.getPassedCourseIds(txCompletedEnrollments);

      const toCreate = this.buildEnrollmentPlan({
        studentId,
        termId: input.termId,
        term: {
          startDate: term.startDate,
          maxCredits: term.maxCredits
        },
        now,
        cartItems: txCartItems,
        existingEnrollments: txExistingEnrollments,
        passedCourseIds: txPassedCourseIds,
        enrolledCountBySection: new Map(txSectionStats.enrolledCountBySection),
        maxWaitlistPositionBySection: new Map(txSectionStats.maxWaitlistPositionBySection)
      });

      await tx.enrollment.createMany({ data: toCreate });
      await tx.cartItem.deleteMany({ where: { studentId, termId: input.termId } });

      return tx.enrollment.findMany({
        where: {
          studentId,
          termId: input.termId,
          sectionId: { in: toCreate.map((item) => item.sectionId) }
        },
        include: {
          section: { include: { course: true, meetingTimes: true } }
        },
        orderBy: { createdAt: "desc" }
      });
    });

    await this.auditService.log({
      actorUserId: studentId,
      action: "enroll_submit",
      entityType: "enrollment",
      metadata: {
        termId: input.termId,
        count: created.length,
        statuses: created.map((item) => item.status)
      },
      req
    });

    return created;
  }

  async dropEnrollment(studentId: string, input: DropEnrollmentInput, req: Request) {
    const enrollment = await this.prisma.enrollment.findUnique({
      where: { id: input.enrollmentId },
      include: { term: true }
    });

    if (!enrollment || enrollment.studentId !== studentId) {
      throw new NotFoundException({ code: "ENROLLMENT_NOT_FOUND", message: "Enrollment not found" });
    }

    if (enrollment.status === "DROPPED") {
      throw new BadRequestException({ code: "ALREADY_DROPPED", message: "Enrollment already dropped" });
    }

    const previousStatus = enrollment.status;
    const seatFreed = previousStatus === "ENROLLED";

    if (previousStatus === "WAITLISTED") {
      const droppedResult = await this.prisma.$transaction(async (tx) => {
        const current = await tx.enrollment.findUnique({
          where: { id: enrollment.id },
          select: {
            id: true,
            studentId: true,
            status: true,
            sectionId: true,
            waitlistPosition: true
          }
        });

        if (!current || current.studentId !== studentId) {
          throw new NotFoundException({ code: "ENROLLMENT_NOT_FOUND", message: "Enrollment not found" });
        }

        if (current.status !== "WAITLISTED") {
          throw new BadRequestException({
            code: "ENROLLMENT_STATE_CHANGED",
            message: "Enrollment state changed, please retry"
          });
        }

        const oldWaitlistPosition = current.waitlistPosition;

        const dropped = await tx.enrollment.update({
          where: { id: current.id },
          data: {
            status: "DROPPED",
            droppedAt: new Date(),
            waitlistPosition: null
          }
        });

        if (oldWaitlistPosition !== null) {
          await tx.enrollment.updateMany({
            where: {
              sectionId: current.sectionId,
              status: "WAITLISTED",
              waitlistPosition: { gt: oldWaitlistPosition }
            },
            data: {
              waitlistPosition: { increment: 10000 }
            }
          });

          await tx.enrollment.updateMany({
            where: {
              sectionId: current.sectionId,
              status: "WAITLISTED",
              waitlistPosition: { gt: oldWaitlistPosition + 10000 }
            },
            data: {
              waitlistPosition: { decrement: 9999 }
            }
          });
        }

        return {
          dropped,
          sectionId: current.sectionId,
          oldWaitlistPosition
        };
      });

      await this.auditService.log({
        actorUserId: studentId,
        action: "drop",
        entityType: "enrollment",
        entityId: enrollment.id,
        metadata: {
          previousStatus,
          sectionId: droppedResult.sectionId,
          oldWaitlistPosition: droppedResult.oldWaitlistPosition,
          seatFreed: false
        },
        req
      });

      return {
        dropped: droppedResult.dropped,
        seatFreed: false
      };
    }

    if (
      (enrollment.status === "ENROLLED" || enrollment.status === "PENDING_APPROVAL") &&
      new Date() > enrollment.term.dropDeadline
    ) {
      throw new BadRequestException({
        code: "DROP_DEADLINE_PASSED",
        message: "Contact advisor/registrar"
      });
    }

    const dropped = await this.prisma.enrollment.update({
      where: { id: enrollment.id },
      data: {
        status: "DROPPED",
        droppedAt: new Date(),
        waitlistPosition: null
      }
    });

    await this.auditService.log({
      actorUserId: studentId,
      action: "drop",
      entityType: "enrollment",
      entityId: enrollment.id,
      metadata: {
        previousStatus,
        sectionId: enrollment.sectionId,
        oldWaitlistPosition: enrollment.waitlistPosition,
        seatFreed
      },
      req
    });

    return {
      dropped,
      seatFreed
    };
  }

  async listMyEnrollments(studentId: string, termId?: string) {
    return this.prisma.enrollment.findMany({
      where: {
        studentId,
        termId: termId || undefined,
        status: { not: "DROPPED" }
      },
      include: {
        term: true,
        section: {
          include: {
            course: true,
            meetingTimes: true
          }
        }
      },
      orderBy: [{ term: { startDate: "desc" } }, { createdAt: "desc" }]
    });
  }

  async listMySchedule(studentId: string, termId: string) {
    return this.prisma.enrollment.findMany({
      where: {
        studentId,
        termId,
        status: { in: ["ENROLLED", "PENDING_APPROVAL"] }
      },
      include: {
        section: {
          include: {
            course: true,
            meetingTimes: true
          }
        }
      },
      orderBy: { section: { sectionCode: "asc" } }
    });
  }

  async listMyGrades(studentId: string) {
    return this.prisma.enrollment.findMany({
      where: {
        studentId,
        status: "COMPLETED",
        finalGrade: { not: null }
      },
      include: {
        term: true,
        section: {
          include: { course: true }
        }
      },
      orderBy: { updatedAt: "desc" }
    });
  }
}
