import { BadRequestException, Injectable, UnauthorizedException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { Role } from "@prisma/client";
import argon2 from "argon2";
import { randomBytes } from "crypto";
import { Request, Response } from "express";
import {
  ForgotPasswordSchema,
  LoginInput,
  RegisterInput,
  ResetPasswordSchema,
  VerifyEmailSchema
} from "./auth.types";
import { PrismaService } from "../common/prisma.service";
import { AuditService } from "../audit/audit.service";

const ACCESS_COOKIE = "access_token";
const ACCESS_EXPIRES_SECONDS = 60 * 60 * 2;

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwtService: JwtService,
    private readonly auditService: AuditService
  ) {}

  private setAuthCookie(res: Response, token: string) {
    res.cookie(ACCESS_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: false,
      maxAge: ACCESS_EXPIRES_SECONDS * 1000
    });
  }

  async register(input: RegisterInput, req: Request) {
    const invite = await this.prisma.inviteCode.findUnique({ where: { code: input.inviteCode } });
    if (!invite || !invite.active) {
      throw new BadRequestException({ code: "INVALID_INVITE", message: "Invite code is invalid" });
    }
    if (invite.expiresAt && invite.expiresAt < new Date()) {
      throw new BadRequestException({ code: "INVITE_EXPIRED", message: "Invite code expired" });
    }
    if (invite.maxUses && invite.usedCount >= invite.maxUses) {
      throw new BadRequestException({ code: "INVITE_EXHAUSTED", message: "Invite code already used up" });
    }

    const existingUser = await this.prisma.user.findFirst({
      where: {
        OR: [{ email: input.email }, { studentId: input.studentId }]
      }
    });
    if (existingUser) {
      throw new BadRequestException({ code: "USER_EXISTS", message: "Email or studentId already exists" });
    }

    const passwordHash = await argon2.hash(input.password);
    const user = await this.prisma.user.create({
      data: {
        email: input.email,
        studentId: input.studentId,
        passwordHash,
        role: Role.STUDENT,
        studentProfile: {
          create: {
            legalName: input.legalName,
            enrollmentStatus: "New",
            academicStatus: "Active"
          }
        }
      }
    });

    await this.prisma.inviteCode.update({
      where: { id: invite.id },
      data: { usedCount: { increment: 1 } }
    });

    const token = randomBytes(32).toString("hex");
    await this.prisma.emailVerificationToken.create({
      data: {
        token,
        userId: user.id,
        expiresAt: new Date(Date.now() + 24 * 60 * 60 * 1000)
      }
    });

    const activationLink = `${process.env.WEB_URL || "http://localhost:3000"}/verify?token=${token}`;

    await this.auditService.log({
      actorUserId: user.id,
      action: "register",
      entityType: "user",
      entityId: user.id,
      metadata: { email: user.email },
      req
    });

    return {
      message: "Registration successful. Verify email before login.",
      activationLink
    };
  }

  async verifyEmail(input: VerifyEmailSchema) {
    const tokenRecord = await this.prisma.emailVerificationToken.findUnique({ where: { token: input.token } });

    if (!tokenRecord || tokenRecord.usedAt || tokenRecord.expiresAt < new Date()) {
      throw new BadRequestException({ code: "INVALID_TOKEN", message: "Verification token is invalid or expired" });
    }

    await this.prisma.$transaction([
      this.prisma.emailVerificationToken.update({
        where: { id: tokenRecord.id },
        data: { usedAt: new Date() }
      }),
      this.prisma.user.update({
        where: { id: tokenRecord.userId },
        data: { emailVerifiedAt: new Date() }
      })
    ]);

    return { message: "Email verified" };
  }

  async login(input: LoginInput, req: Request, res: Response) {
    const user = await this.prisma.user.findFirst({
      where: {
        OR: [{ email: input.identifier }, { studentId: input.identifier }]
      },
      include: { studentProfile: true }
    });

    if (!user) {
      throw new UnauthorizedException({ code: "INVALID_CREDENTIALS", message: "Invalid credentials" });
    }

    const validPassword = await argon2.verify(user.passwordHash, input.password);
    if (!validPassword) {
      throw new UnauthorizedException({ code: "INVALID_CREDENTIALS", message: "Invalid credentials" });
    }

    if (!user.emailVerifiedAt) {
      throw new UnauthorizedException({ code: "EMAIL_NOT_VERIFIED", message: "Email must be verified before login" });
    }

    const token = await this.jwtService.signAsync({
      sub: user.id,
      role: user.role
    }, {
      expiresIn: `${ACCESS_EXPIRES_SECONDS}s`
    });

    this.setAuthCookie(res, token);

    await this.auditService.log({
      actorUserId: user.id,
      action: "login",
      entityType: "auth",
      entityId: user.id,
      metadata: { role: user.role },
      req
    });

    return {
      id: user.id,
      email: user.email,
      studentId: user.studentId,
      role: user.role,
      profile: user.studentProfile
    };
  }

  async logout(userId: string, req: Request, res: Response) {
    res.clearCookie(ACCESS_COOKIE);
    await this.auditService.log({
      actorUserId: userId,
      action: "logout",
      entityType: "auth",
      entityId: userId,
      req
    });

    return { message: "Logged out" };
  }

  async forgotPassword(input: ForgotPasswordSchema) {
    const user = await this.prisma.user.findUnique({ where: { email: input.email } });
    if (!user) {
      return { message: "If the account exists, a reset link has been generated" };
    }

    const token = randomBytes(32).toString("hex");
    await this.prisma.passwordResetToken.create({
      data: {
        userId: user.id,
        token,
        expiresAt: new Date(Date.now() + 60 * 60 * 1000)
      }
    });

    const resetLink = `${process.env.WEB_URL || "http://localhost:3000"}/reset?token=${token}`;
    return {
      message: "If the account exists, a reset link has been generated",
      resetLink
    };
  }

  async resetPassword(input: ResetPasswordSchema) {
    const tokenRecord = await this.prisma.passwordResetToken.findUnique({ where: { token: input.token } });

    if (!tokenRecord || tokenRecord.usedAt || tokenRecord.expiresAt < new Date()) {
      throw new BadRequestException({ code: "INVALID_TOKEN", message: "Reset token is invalid or expired" });
    }

    const passwordHash = await argon2.hash(input.newPassword);
    await this.prisma.$transaction([
      this.prisma.user.update({
        where: { id: tokenRecord.userId },
        data: { passwordHash }
      }),
      this.prisma.passwordResetToken.update({
        where: { id: tokenRecord.id },
        data: { usedAt: new Date() }
      })
    ]);

    return { message: "Password reset successful" };
  }

  async me(userId: string) {
    const user = await this.prisma.user.findUnique({
      where: { id: userId },
      include: { studentProfile: true }
    });
    if (!user) {
      throw new UnauthorizedException({ code: "USER_NOT_FOUND", message: "User not found" });
    }

    return {
      id: user.id,
      email: user.email,
      studentId: user.studentId,
      role: user.role,
      emailVerifiedAt: user.emailVerifiedAt,
      profile: user.studentProfile
    };
  }
}
